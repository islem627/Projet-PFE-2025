package com.example.user_service.entities;


import jakarta.persistence.*;

@Entity

public class UserEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, unique = true)
    private String email;

    private String username;
    //private String email;
    private  String password;
    private  String address;
    private  String phone;
    @Lob
    private String photo;
    //private  String photo;
    private  String firstname;
    private  String lastname;
     private  Boolean confirme=false;
     private  String role ;
    private String passwordResetToken;
    private String gouvernorat ; // ex: "Nord", "Sud", null pour non-livreurs

    public String getGouvernorat() {
        return gouvernorat;
    }

    public void setGouvernorat(String gouvernorat) {
        this.gouvernorat = gouvernorat;
    }

    public String getPasswordResetToken() {
        return passwordResetToken;
    }

    public void setPasswordResetToken(String passwordResetToken) {
        this.passwordResetToken = passwordResetToken;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public Boolean getConfirme() {
        return confirme;
    }

    public void setConfirme(Boolean confirme) {
        this.confirme = confirme;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }


    public UserEntity() {
    }

    public UserEntity(Long id, String email, String username, String password, String address, String phone, String photo, String firstname, String lastname, Boolean confirme, String role, String passwordResetToken, String gouvernorat) {
        this.id = id;
        this.email = email;
        this.username = username;
        this.password = password;
        this.address = address;
        this.phone = phone;
        this.photo = photo;
        this.firstname = firstname;
        this.lastname = lastname;
        this.confirme = confirme;
        this.role = role;
        this.passwordResetToken = passwordResetToken;
        this.gouvernorat = gouvernorat;
    }
}
