package com.example.mschatsocket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsChatSocketApplicationTests {

    @Test
    void contextLoads() {
    }

}
