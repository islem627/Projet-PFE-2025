package com.example.realtime24;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RealTime24ApplicationTests {

    @Test
    void contextLoads() {
    }

}
