package com.example.realtime24.controller;

import com.example.realtime24.DTO.CommandeDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

@Controller
public class OrderNotificationController {

    @Autowired
    private SimpMessagingTemplate simpMessagingTemplate;

    @MessageMapping("/order/status")
    public void sendOrderUpdate(OrderUpdate orderUpdate) {
        String clientId = String.valueOf(orderUpdate.getCommandeDTO().getIduser());
        String destination = "/user/" + clientId + "/queue/order";

        // Filtrer les données sensibles
        CommandeDTO filteredCommandeDTO = new CommandeDTO();
        filteredCommandeDTO.setId_commande(orderUpdate.getCommandeDTO().getId_commande());
        filteredCommandeDTO.setStatut_commande(orderUpdate.getCommandeDTO().getStatut_commande());
        filteredCommandeDTO.setIduser(orderUpdate.getCommandeDTO().getIduser());

        OrderUpdate filteredOrderUpdate = new OrderUpdate();
        filteredOrderUpdate.setOrderId(orderUpdate.getOrderId());
        filteredOrderUpdate.setStatus(orderUpdate.getStatus());
        filteredOrderUpdate.setCommandeDTO(filteredCommandeDTO);

        System.out.println("📥 Message reçu pour /app/order/status: " + filteredOrderUpdate);
        System.out.println("👉 Envoi notification à l'utilisateur ID: " + clientId);
        System.out.println("Commande ID: " + filteredOrderUpdate.getOrderId() + ", Statut: " + filteredOrderUpdate.getStatus());
        System.out.println("Destination: " + destination);

        try {
            simpMessagingTemplate.convertAndSend(destination, filteredOrderUpdate);
            System.out.println("✅ Notification envoyée avec succès à " + destination);
        } catch (Exception e) {
            System.err.println("❌ Erreur lors de l'envoi de la notification: " + e.getMessage());
            e.printStackTrace();
        }
    }
}